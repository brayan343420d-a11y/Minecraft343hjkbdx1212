package com.nubi.enacurtain.mixin;

import com.nubi.enacurtain.EnaCurtainClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
    private void ena$moveHands(
            AbstractClientPlayerEntity player,
            float tickDelta,
            float pitch,
            Hand hand,
            float swingProgress,
            ItemStack item,
            float equipProgress,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            CallbackInfo ci
    ) {
        float p = EnaCurtainClient.openingProgress(tickDelta);
        if (p <= 0.0f) return;

        Arm arm = hand == Hand.MAIN_HAND
                ? player.getMainArm()
                : player.getMainArm().getOpposite();

        float side = arm == Arm.RIGHT ? 1.0f : -1.0f;

        // Move the real vanilla arm/hand outward as the curtain opens.
        matrices.translate(side * 0.75f * p, 0.0f, 0.0f);
    }
}
