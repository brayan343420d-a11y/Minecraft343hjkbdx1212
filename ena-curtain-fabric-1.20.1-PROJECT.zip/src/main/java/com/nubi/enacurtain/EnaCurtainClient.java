package com.nubi.enacurtain;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

public class EnaCurtainClient implements ClientModInitializer {
    public enum Phase { NONE, BLACK, OPENING }

    public static Phase phase = Phase.NONE;
    private static int timer;
    private static boolean escWasDown;

    private static final int BLACK_TICKS = 24;   // 1.2 s
    private static final int OPEN_TICKS = 24;    // 1.2 s

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(EnaCurtainMod.INTRO_PACKET,
                (client, handler, buf, responseSender) -> {
                    buf.readByte();
                    client.execute(EnaCurtainClient::start);
                });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (phase == Phase.NONE) {
                escWasDown = false;
                return;
            }

            long window = client.getWindow().getHandle();
            boolean escDown = InputUtil.isKeyPressed(window, GLFW.GLFW_KEY_ESCAPE);

            if (escDown && !escWasDown) {
                skip();
            }
            escWasDown = escDown;

            if (phase == Phase.NONE) return;

            timer++;

            if (phase == Phase.BLACK && timer >= BLACK_TICKS) {
                phase = Phase.OPENING;
                timer = 0;
            } else if (phase == Phase.OPENING && timer >= OPEN_TICKS) {
                phase = Phase.NONE;
                timer = 0;
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            if (phase != Phase.NONE) {
                render(drawContext, tickDelta);
            }
        });
    }

    public static void start() {
        phase = Phase.BLACK;
        timer = 0;
    }

    public static void skip() {
        phase = Phase.NONE;
        timer = 0;
    }

    public static float openingProgress(float tickDelta) {
        if (phase != Phase.OPENING) return 0.0f;
        float t = (timer + tickDelta) / (float) OPEN_TICKS;
        t = MathHelper.clamp(t, 0.0f, 1.0f);
        return t * t * (3.0f - 2.0f * t);
    }

    private static void render(DrawContext ctx, float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();
        int w = client.getWindow().getScaledWidth();
        int h = client.getWindow().getScaledHeight();

        if (phase == Phase.BLACK) {
            ctx.fill(0, 0, w, h, 0xFF000000);
            return;
        }

        float p = openingProgress(tickDelta);
        int center = w / 2;

        // The black panels begin together at the center and slide to the edges.
        int gapHalf = (int) (center * p);

        ctx.fill(0, 0, center - gapHalf, h, 0xFF000000);
        ctx.fill(center + gapHalf, 0, w, h, 0xFF000000);
    }
}
