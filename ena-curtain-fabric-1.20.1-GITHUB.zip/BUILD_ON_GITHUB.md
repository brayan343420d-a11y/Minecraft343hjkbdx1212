## Compilar en GitHub

Sube el contenido de este proyecto a un repositorio.
Ve a Actions -> Build ENA Curtain -> Run workflow.
El JAR aparecerá en Artifacts como `ena-curtain`.

Minecraft: 1.20.1
Java: 17
Fabric API: 0.92.12+1.20.1
Loom: 1.10.5
