# ENA Curtain Intro — Fabric 1.20.1

Client/server Fabric mod for Minecraft 1.20.1.

- Black screen when joining a world.
- Black screen opens from the center like curtains.
- The vanilla first-person player arms/hands are moved outward during the opening.
- Runs again after a death/respawn.
- ESC skips the intro.
- Fabric API 0.92.12+1.20.1.
- Java 17.

## GitHub

Upload the CONTENTS of this project to the repository root. Do not upload this ZIP as the only project file.

Then run:
Actions -> Build ENA Curtain -> Run workflow.

The compiled JAR will be under Artifacts.
