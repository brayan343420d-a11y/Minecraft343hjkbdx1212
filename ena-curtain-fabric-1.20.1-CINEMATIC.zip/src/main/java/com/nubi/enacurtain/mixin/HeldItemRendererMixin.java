package com.nubi.enacurtain.mixin;

import com.nubi.enacurtain.EnaCurtainClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
    /**
     * Move the real vanilla first-person arms, rather than drawing replacement rectangles.
     * renderArm is the method Minecraft uses to render the player's actual skin arm/hand.
     */
    @Inject(method = "renderArm", at = @At("HEAD"))
    private void ena$moveRealArm(
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            Arm arm,
            CallbackInfo ci
    ) {
        float p = EnaCurtainClient.openingProgress(0.0f);
        if (p <= 0.0f) return;

        float side = arm == Arm.RIGHT ? 1.0f : -1.0f;
        float shake = EnaCurtainClient.struggleShake(0.0f, side);

        // The first part looks like the character is struggling against the curtains.
        float effort = Math.min(p / 0.28f, 1.0f);
        float outward = 0.16f * effort + 0.58f * p;

        // Small forward movement and a sideways rotation sell the pushing motion.
        matrices.translate(side * (outward + shake), 0.035f * effort, 0.0f);
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * (-5.0f * effort)));

        // A quick extra shove during the last part of the opening.
        if (p > 0.78f) {
            float shove = (p - 0.78f) / 0.22f;
            shove = shove * shove;
            matrices.translate(side * 0.16f * shove, 0.0f, -0.05f * shove);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 7.0f * shove));
        }
    }
}
