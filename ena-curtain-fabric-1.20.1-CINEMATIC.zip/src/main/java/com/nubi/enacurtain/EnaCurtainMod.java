package com.nubi.enacurtain;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

public class EnaCurtainMod implements ModInitializer {
    public static final String MOD_ID = "ena_curtain";
    public static final Identifier INTRO_PACKET = new Identifier(MOD_ID, "intro");

    @Override
    public void onInitialize() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            sendIntro(handler.getPlayer(), (byte) 0);
        });

        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            if (!alive) {
                sendIntro(newPlayer, (byte) 1);
            }
        });
    }

    private static void sendIntro(ServerPlayerEntity player, byte type) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeByte(type);
        ServerPlayNetworking.send(player, INTRO_PACKET, buf);
    }
}
