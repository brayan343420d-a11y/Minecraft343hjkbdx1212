package com.nubi.enacurtain;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

public class EnaCurtainClient implements ClientModInitializer {
    public enum Phase { NONE, BLACK, OPENING }

    public static Phase phase = Phase.NONE;
    private static int timer;
    private static boolean escWasDown;
    private static boolean deathIntro;

    // About 4 seconds of black screen before the curtains move.
    private static final int BLACK_TICKS = 80;
    // A short, forceful opening after the struggle.
    private static final int OPEN_TICKS = 32;

    private static final String JOIN_TEXT = "ah!, estamos aqui!, a jugar.";
    private static final String DEATH_TEXT = "maldita sea eso me dolio.., mis cosas estaran bien?";

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(EnaCurtainMod.INTRO_PACKET,
                (client, handler, buf, responseSender) -> {
                    byte type = buf.readByte();
                    client.execute(() -> start(type == 1));
                });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (phase == Phase.NONE) {
                escWasDown = false;
                return;
            }

            long window = client.getWindow().getHandle();
            boolean escDown = InputUtil.isKeyPressed(window, GLFW.GLFW_KEY_ESCAPE);

            if (escDown && !escWasDown) {
                skip();
            }
            escWasDown = escDown;

            if (phase == Phase.NONE) return;

            timer++;

            if (phase == Phase.BLACK && timer >= BLACK_TICKS) {
                phase = Phase.OPENING;
                timer = 0;
            } else if (phase == Phase.OPENING && timer >= OPEN_TICKS) {
                phase = Phase.NONE;
                timer = 0;
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            if (phase != Phase.NONE) {
                render(drawContext, tickDelta);
            }
        });
    }

    public static void start(boolean isDeath) {
        deathIntro = isDeath;
        phase = Phase.BLACK;
        timer = 0;
    }

    public static void skip() {
        phase = Phase.NONE;
        timer = 0;
    }

    public static float openingProgress(float tickDelta) {
        if (phase != Phase.OPENING) return 0.0f;
        float t = (timer + tickDelta) / (float) OPEN_TICKS;
        t = MathHelper.clamp(t, 0.0f, 1.0f);
        // Slow start, then a sharp final push.
        if (t < 0.68f) {
            float a = t / 0.68f;
            return 0.28f * (a * a * (3.0f - 2.0f * a));
        }
        float a = (t - 0.68f) / 0.32f;
        a = a * a * (3.0f - 2.0f * a);
        return 0.28f + 0.72f * a;
    }

    /** Small irregular shake while the curtains are being fought open. */
    public static float struggleShake(float tickDelta, float side) {
        if (phase != Phase.OPENING) return 0.0f;
        float t = (timer + tickDelta) / (float) OPEN_TICKS;
        if (t > 0.72f) return 0.0f;
        float strength = MathHelper.clamp(t / 0.72f, 0.0f, 1.0f);
        strength *= strength;
        float wobble = (float) Math.sin((timer + tickDelta) * 2.35f)
                + 0.45f * (float) Math.sin((timer + tickDelta) * 5.7f + 1.4f);
        return wobble * 0.010f * strength * side;
    }

    private static void render(DrawContext ctx, float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();
        int w = client.getWindow().getScaledWidth();
        int h = client.getWindow().getScaledHeight();

        if (phase == Phase.BLACK) {
            drawCurtain(ctx, 0, w / 2, h, false, 0.0f);
            drawCurtain(ctx, w / 2, w, h, true, 0.0f);
            drawText(ctx, deathIntro ? DEATH_TEXT : JOIN_TEXT, w, h);
            return;
        }

        float p = openingProgress(tickDelta);
        int center = w / 2;
        int gapHalf = (int) (center * p);

        drawCurtain(ctx, 0, center - gapHalf, h, false, p);
        drawCurtain(ctx, center + gapHalf, w, h, true, p);

        // Keep the message visible during the opening, then let it disappear with the curtains.
        if (p < 0.92f) {
            drawText(ctx, deathIntro ? DEATH_TEXT : JOIN_TEXT, w, h);
        }
    }

    private static void drawCurtain(DrawContext ctx, int left, int right, int h, boolean rightSide, float p) {
        if (right <= left) return;

        // Near-black instead of a completely flat rectangle, with subtle vertical cloth folds.
        ctx.fill(left, 0, right, h, 0xFF050505);

        int width = right - left;
        int bands = Math.max(5, Math.min(12, width / 45));
        for (int i = 1; i < bands; i++) {
            int x = left + (width * i / bands);
            int bandWidth = Math.max(1, width / 80);
            int shade = (i % 2 == 0) ? 0xFF0A0A0A : 0xFF020202;
            ctx.fill(x, 0, Math.min(right, x + bandWidth), h, shade);
        }

        // Slight edge highlight makes the two black curtains readable against each other.
        if (p > 0.0f) {
            int edge = rightSide ? left : right - 1;
            ctx.fill(edge, 0, edge + 1, h, 0xFF181818);
        }
    }

    private static void drawText(DrawContext ctx, String text, int w, int h) {
        MinecraftClient client = MinecraftClient.getInstance();
        int textWidth = client.textRenderer.getWidth(text);
        int x = (w - textWidth) / 2;
        int y = h - 28;

        // Shadow, then the actual text for a simple cinematic subtitle.
        ctx.drawText(client.textRenderer, text, x + 1, y + 1, 0xFF000000, false);
        ctx.drawText(client.textRenderer, text, x, y, 0xFFE8E8E8, false);
    }
}
