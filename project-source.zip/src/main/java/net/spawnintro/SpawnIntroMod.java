package net.spawnintro;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.ServerPlayerEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

/**
 * Mod ligero: muestra una "intro" (pantalla negra con texto que luego se abre
 * como cortinas) al aparecer el jugador y al reaparecer tras morir.
 *
 * Tipos de paquete enviados al cliente:
 *   0 = texto de bienvenida (spawn)
 *   1 = variante de muerte A
 *   2 = variante de muerte B
 */
public class SpawnIntroMod implements ModInitializer {

	public static final String MOD_ID = "spawnintro";
	public static final Identifier INTRO_PACKET_ID = new Identifier(MOD_ID, "show_intro");

	@Override
	public void onInitialize() {

		// Cuando el jugador aparece por primera vez en el mundo (se une).
		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			ServerPlayerEntity player = handler.getPlayer();
			PacketByteBuf buf = PacketByteBufs.create();
			buf.writeByte(0); // bienvenida
			ServerPlayNetworking.send(player, INTRO_PACKET_ID, buf);
		});

		// Cuando el jugador reaparece después de morir.
		// "alive" es true si el respawn NO fue por muerte (ej. portal del End),
		// así que solo disparamos la intro de muerte cuando alive == false.
		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
			if (!alive) {
				int variant = newPlayer.getRandom().nextInt(2) + 1; // 1 o 2
				PacketByteBuf buf = PacketByteBufs.create();
				buf.writeByte(variant);
				ServerPlayNetworking.send(newPlayer, INTRO_PACKET_ID, buf);
			}
		});
	}
}
