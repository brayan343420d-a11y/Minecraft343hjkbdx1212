package net.spawnintro;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Lado cliente del mod. Mantiene una pequeña máquina de estados:
 *
 *   NONE  -> nada que mostrar.
 *   TEXT  -> pantalla negra completa + texto centrado abajo (dura ~3s).
 *   OPENING -> las dos mitades negras se separan hacia los bordes,
 *              con un "brazo" simple empujando cada una.
 *
 * Se puede saltar en cualquier momento presionando ESCAPE (ver KeyboardMixin).
 */
public class SpawnIntroClient implements ClientModInitializer {

	public enum Phase { NONE, TEXT, OPENING }

	// Duraciones en ticks (20 ticks = 1 segundo)
	private static final int TEXT_DURATION = 60;   // 3 segundos
	private static final int OPEN_DURATION = 16;   // ~0.8 segundos

	public static Phase phase = Phase.NONE;
	private static String currentText = "";
	private static int timer = 0;

	@Override
	public void onInitializeClient() {

		// Recibe el paquete del servidor y arranca la intro correspondiente.
		ClientPlayNetworking.registerGlobalReceiver(SpawnIntroMod.INTRO_PACKET_ID, (client, handler, buf, responseSender) -> {
			byte type = buf.readByte();
			client.execute(() -> startIntro(type));
		});

		// Avanza el temporizador cada tick del cliente.
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (phase == Phase.NONE) return;

			timer++;
			if (phase == Phase.TEXT && timer >= TEXT_DURATION) {
				phase = Phase.OPENING;
				timer = 0;
			} else if (phase == Phase.OPENING && timer >= OPEN_DURATION) {
				phase = Phase.NONE;
				timer = 0;
			}
		});

		// Dibuja el overlay encima del HUD normal.
		HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
			if (phase != Phase.NONE) {
				render(drawContext);
			}
		});
	}

	private static void startIntro(byte type) {
		currentText = switch (type) {
			case 1 -> "valla e muerto..espero mis cosas esten a salvo";
			case 2 -> "eso dolio...a ponerse a marcha que este mundo no se juega solo!";
			default -> "hey. hey! oye es hora de ser creativo a jugar ahora!";
		};
		phase = Phase.TEXT;
		timer = 0;
	}

	/** Llamado por el mixin de teclado cuando el jugador presiona ESCAPE. */
	public static void skip() {
		if (phase != Phase.NONE) {
			phase = Phase.NONE;
			timer = 0;
		}
	}

	private static void render(DrawContext drawContext) {
		MinecraftClient client = MinecraftClient.getInstance();
		int width = client.getWindow().getScaledWidth();
		int height = client.getWindow().getScaledHeight();
		int center = width / 2;
		int black = 0xFF000000;

		if (phase == Phase.TEXT) {
			// Pantalla completamente negra con el texto abajo.
			drawContext.fill(0, 0, width, height, black);
			drawContext.drawCenteredTextWithShadow(
					client.textRenderer,
					currentText,
					center,
					height - 40,
					0xFFFFFF
			);
		} else if (phase == Phase.OPENING) {
			// Las dos mitades se separan desde el centro hacia los bordes.
			float progress = Math.min(1f, timer / (float) OPEN_DURATION);
			// easing simple para que se sienta menos brusco
			float eased = 1f - (1f - progress) * (1f - progress);
			int offset = (int) (eased * center);

			// panel izquierdo y derecho
			drawContext.fill(0, 0, center - offset, height, black);
			drawContext.fill(center + offset, 0, width, height, black);

			// "brazos" simples empujando cada panel (rectángulos color piel)
			int armHeight = 34;
			int armY = height / 2 - armHeight / 2;
			int armWidth = 22;

			drawContext.fill(center - offset - armWidth, armY, center - offset, armY + armHeight, 0xFFC896);
			drawContext.fill(center + offset, armY, center + offset + armWidth, armY + armHeight, 0xFFC896);
		}
	}
}
