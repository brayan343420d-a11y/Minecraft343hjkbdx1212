package net.spawnintro.mixin;

import net.minecraft.client.Keyboard;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.spawnintro.SpawnIntroClient;

@Mixin(Keyboard.class)
public class KeyboardMixin {

	@Inject(method = "onKey", at = @At("HEAD"), cancellable = true)
	private void spawnintro$onKey(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
		if (key == GLFW.GLFW_KEY_ESCAPE
				&& action == GLFW.GLFW_PRESS
				&& SpawnIntroClient.phase != SpawnIntroClient.Phase.NONE) {
			SpawnIntroClient.skip();
			ci.cancel();
		}
	}
}
