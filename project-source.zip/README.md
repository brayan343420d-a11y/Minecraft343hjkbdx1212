# Spawn Intro (Fabric 1.20.1)

Mod ligero que muestra una intro tipo "pantalla negra que se abre como cortinas"
al aparecer en el mundo y al reaparecer después de morir.

## Qué hace

- **Al aparecer (spawn/join):** pantalla negra con el texto
  `"hey. hey! oye es hora de ser creativo a jugar ahora!"` durante 3 segundos,
  luego dos "brazos" simples abren la pantalla negra en dos mitades hacia los lados.
- **Al morir y reaparecer:** mismo efecto, pero con una de estas dos frases al azar:
  - `"valla e muerto..espero mis cosas esten a salvo"`
  - `"eso dolio...a ponerse a marcha que este mundo no se juega solo!"`
- **ESCAPE** en cualquier momento salta/omite la intro.

Todo el renderizado es simple (rectángulos con `DrawContext.fill` y texto),
sin modelos 3D ni texturas extra, para mantenerlo ligero.

## Cómo compilarlo

No tengo acceso a internet en este entorno para descargar Gradle/Fabric y
compilar el .jar por ti, así que te dejo los pasos para hacerlo tú (es rápido):

1. Instala **Java 17** (JDK), si no lo tienes.
2. Ve a este proyecto en tu computadora (esta carpeta `spawnintro/`).
3. Abre una terminal dentro de la carpeta y ejecuta:
   - Windows: `gradlew.bat build`
   - Mac/Linux: `./gradlew build`

   > Nota: este proyecto no incluye el "gradle wrapper" (los archivos
   > `gradlew`, `gradlew.bat` y `gradle/wrapper/...`) porque son binarios que
   > no puedo generar sin internet. Lo más fácil es:
   > 1. Descarga el **Fabric Example Mod** desde
   >    https://fabricmc.net/develop/template/ (selecciona Minecraft 1.20.1).
   > 2. Descomprime ese ejemplo — ya trae el wrapper de Gradle listo.
   > 3. Copia/reemplaza dentro de ese proyecto los archivos de esta carpeta
   >    (`build.gradle`, `gradle.properties`, `settings.gradle`, y toda la
   >    carpeta `src/`), sobrescribiendo lo que ya traía el ejemplo.
   > 4. Ahora sí corre `./gradlew build` (o `gradlew.bat build` en Windows)
   >    dentro de esa carpeta.

4. El .jar compilado quedará en `build/libs/spawnintro-1.0.0.jar`.

## Cómo instalarlo

1. Instala **Fabric Loader** para Minecraft 1.20.1 (fabricmc.net/use).
2. Descarga **Fabric API** para 1.20.1 y ponlo en tu carpeta `mods`.
3. Copia `spawnintro-1.0.0.jar` a la carpeta `mods` de tu instalación.
4. Abre Minecraft con el perfil de Fabric y entra a un mundo.

## Personalizar textos/tiempos

Todo está en `SpawnIntroClient.java`:
- `TEXT_DURATION` / `OPEN_DURATION`: duración en ticks (20 = 1 segundo).
- El `switch` en `startIntro(...)`: ahí están los 3 textos.

## Nota importante (no compilado/probado)

Este código está escrito a mano siguiendo las APIs conocidas de Fabric API
para 1.20.1, pero no pude compilarlo ni probarlo en este entorno porque no
tengo acceso a internet para descargar las dependencias de Minecraft/Fabric.
Es muy probable que funcione tal cual, pero si al compilar sale algún error
de nombres de métodos (las mappings de Yarn a veces cambian ligeramente
entre builds), pégame el error y lo corregimos.
